import { type FormEvent, useEffect, useRef, useState } from 'react';
import { Link, Route, Router as WouterRouter, Switch, useLocation } from 'wouter';
import {
  ArrowDown, ArrowLeft, ArrowRight, BookOpen, ChevronRight, Expand,
  KeyRound, Leaf, RotateCcw, Sparkles, X,
} from 'lucide-react';
import { embeddedPages } from './embeddedPages';

const books = [
  { title: 'The Atlas of Small Things', author: 'Mira Bell', tag: 'A field guide to wonder', art: 'atlas', note: 'A pocket-sized map of overlooked marvels, from rain-window constellations to the secret lives of teacups.' },
  { title: 'When the Moon Kept House', author: 'Eloise Finch', tag: 'A tale for late evenings', art: 'moon', note: 'One moonlit evening, a quiet little house begins collecting all the things the night has misplaced.' },
  { title: 'The Garden Behind the Clock', author: 'Noah Wren', tag: 'A gentle mystery', art: 'garden', note: 'A clock that runs a minute slow. A door in the wallpaper. A garden that seems to know your name.' },
  { title: 'Postcards from Elsewhere', author: 'June Avery', tag: 'A collection of journeys', art: 'postcard', note: 'Tiny dispatches from imaginary coastlines, cloud towns, and one very patient lighthouse keeper.' },
];
const memoryWords = ['fern', 'comet', 'shell', 'lantern', 'fern', 'comet', 'shell', 'lantern'];
const memoryMarks = ['✳', '✦', '⌂', '◌', '✳', '✦', '⌂', '◌'];

function Header({ room = false }: { room?: boolean }) {
  return <header className="site-header">
    <Link href="/" className="brand" aria-label="Storybook Vault home"><span className="brand-mark"><BookOpen size={18} /></span><span>storybook <b>vault</b></span></Link>
    <div className="header-note">{room ? 'A little room of your own' : 'A library for curious minds'}</div>
    {room ? <Link href="/" className="header-link"><ArrowLeft size={16} /> Library</Link> : <a className="header-link" href="#the-vault">Find the vault <ArrowDown size={15} /></a>}
  </header>;
}

function Home() {
  const [code, setCode] = useState('');
  const [error, setError] = useState(false);
  const [selected, setSelected] = useState<number | null>(null);
  const [, setLocation] = useLocation();
  useEffect(() => {
    document.title = 'Storybook Vault — a little place for wonder';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) meta.setAttribute('content', 'A welcoming library of illustrated stories, small discoveries, and a tucked-away room of gentle activities.');
  }, []);
  function unlock(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (code.trim() === '1234') {
      sessionStorage.setItem('storybook-vault-unlocked', 'yes');
      setLocation('/room');
    } else {
      setError(true);
    }
  }
  return <main className="home-page">
    <Header />
    <section className="hero">
      <div className="hero-copy reveal">
        <div className="eyebrow"><span className="eyebrow-dot" /> THE LITTLE LIBRARY <span className="eyebrow-line" /></div>
        <h1>Somewhere<br />between <i>pages,</i><br />there’s a <em>place.</em></h1>
        <p>A shelf of illustrated stories, small discoveries, and one quiet door waiting to be found.</p>
        <a href="#collection" className="button button-dark">Wander the shelves <ArrowDown size={16} /></a>
        <span className="hero-footnote"><Sparkles size={14} /> Take your time. Nothing here is in a hurry.</span>
      </div>
      <div className="hero-art reveal reveal-delay" aria-label="Illustration of a cozy reading nook">
        <div className="sun-disc" />
        <div className="window-frame"><div className="window-cross" /><div className="window-sill" /></div>
        <div className="star star-one">✦</div><div className="star star-two">✳</div><div className="star star-three">·</div>
        <div className="plant plant-a"><i /><i /><i /><b /></div>
        <div className="stack-book stack-back" /><div className="stack-book stack-mid" /><div className="stack-book stack-front" />
        <div className="hero-caption"><span>Fig. 01</span> A window that always has time</div>
      </div>
      <span className="hero-side-note">ISSUE NO. 04&nbsp; · &nbsp;EST. IN DAYDREAMS</span>
    </section>
    <section id="collection" className="collection-section">
      <div className="section-heading">
        <div><div className="eyebrow"><span className="eyebrow-dot" /> THE SHELVES</div><h2>A few good <i>companions.</i></h2></div>
        <p>Stories to open at any page.<br />No particular order required.</p>
      </div>
      <div className="book-grid">
        {books.map((book, index) => <button key={book.title} className={`book-item ${selected === index ? 'is-selected' : ''}`} onClick={() => setSelected(selected === index ? null : index)} aria-pressed={selected === index} data-testid={`button-book-${index}`}>
          <div className={`book-cover ${book.art}`}><span className="cover-index">SV · 0{index + 1}</span><div className="cover-illustration"><span className="cover-orbit" /><span className="cover-object">{['✳', '◒', '⌘', '◌'][index]}</span></div><strong>{book.title}</strong><small>{book.author}</small><span className="cover-rule" /></div>
          <span className="book-meta"><span>{book.tag}</span><ChevronRight size={16} /></span>
        </button>)}
      </div>
      {selected !== null && <div className="book-detail" aria-live="polite"><div className="detail-symbol"><BookOpen size={20} /></div><div><span className="detail-kicker">A NOTE FROM THE SHELF</span><p>{books[selected].note}</p></div><button aria-label="Close book note" onClick={() => setSelected(null)}><X size={17} /></button></div>}
      <div className="shelf-line"><span>Four stories, and room for more</span><span>01 — 04</span></div>
    </section>
    <section className="interlude">
      <div className="interlude-mark"><Leaf size={20} /></div>
      <p>“The best places are the ones you stumble into<br className="desktop-break" /> while looking for something else.”</p>
      <span>A NOTE LEFT BETWEEN THE PAGES</span>
    </section>
    <section className="vault-section" id="the-vault">
      <div className="vault-orbit orbit-one" /><div className="vault-orbit orbit-two" />
      <div className="vault-copy">
        <div className="eyebrow light-eyebrow"><span className="eyebrow-dot" /> PAST THE LAST BOOK</div>
        <h2>There’s a little<br /><i>more,</i> if you know.</h2>
        <p>A tucked-away room with a few gentle diversions. A small code is all it takes.</p>
      </div>
      <form className="vault-form" onSubmit={unlock}>
        <label htmlFor="vault-code">The vault code is 1234.</label>
        <div className="code-row"><div className="input-wrap"><KeyRound size={17} /><input id="vault-code" type="password" inputMode="numeric" maxLength={8} autoComplete="off" placeholder="Enter the code" value={code} onChange={(event) => { setCode(event.target.value); setError(false); }} aria-describedby={error ? 'code-error' : undefined} aria-invalid={error} data-testid="input-vault-code" /></div><button className="button button-cream" type="submit" data-testid="button-unlock">Open <ArrowRight size={16} /></button></div>
        {error && <p id="code-error" role="alert" className="code-error">That one didn’t quite fit. Give it another try.</p>}
        {!error && <span className="form-hint">A small door, just for you.</span>}
      </form>
    </section>
    <footer className="site-footer"><Link href="/" className="brand"><span className="brand-mark"><BookOpen size={16} /></span><span>storybook <b>vault</b></span></Link><span>Made for unhurried afternoons.</span><a href="#top" onClick={(event) => { event.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' }); }}>Back to the beginning ↑</a></footer>
  </main>;
}

function MemoryActivity() {
  const [deck, setDeck] = useState(() => memoryWords.map((word, index) => ({ word, mark: memoryMarks[index], id: index })).sort(() => Math.random() - .5));
  const [open, setOpen] = useState<number[]>([]);
  const [matched, setMatched] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [locked, setLocked] = useState(false);
  function restart() { setDeck(memoryWords.map((word, index) => ({ word, mark: memoryMarks[index], id: index })).sort(() => Math.random() - .5)); setOpen([]); setMatched([]); setMoves(0); setLocked(false); }
  function flip(id: number) {
    if (locked || open.includes(id) || matched.includes(id)) return;
    if (open.length === 0) { setOpen([id]); return; }
    const first = deck.find((card) => card.id === open[0]);
    const second = deck.find((card) => card.id === id);
    setMoves((count) => count + 1);
    setOpen([open[0], id]);
    if (first?.word === second?.word) {
      setMatched((cards) => [...cards, open[0], id]);
      window.setTimeout(() => setOpen([]), 550);
    } else {
      setLocked(true);
      window.setTimeout(() => { setOpen([]); setLocked(false); }, 850);
    }
  }
  return <div className="memory-activity">
    <div className="activity-toolbar"><span>{matched.length === 8 ? 'Every pair found. Nicely done.' : `Pairs found ${matched.length / 2} of 4`}</span><span className="move-count">{moves} turns</span></div>
    <div className="memory-grid">{deck.map((card) => { const revealed = open.includes(card.id) || matched.includes(card.id); return <button key={card.id} className={`memory-card ${revealed ? 'revealed' : ''} ${matched.includes(card.id) ? 'matched' : ''}`} onClick={() => flip(card.id)} aria-label={revealed ? card.word : 'Reveal a card'} aria-pressed={revealed} data-testid={`memory-card-${card.id}`}><span className="card-back-mark">{revealed ? card.mark : '✦'}</span><small>{revealed ? card.word : 'look'}</small></button>; })}</div>
    <button className="text-button" onClick={restart}><RotateCcw size={15} /> Begin again</button>
  </div>;
}

function PatternActivity() {
  const [answer, setAnswer] = useState<string | null>(null);
  const [round, setRound] = useState(0);
  const patterns = [
    { sequence: ['moss', 'amber', 'moss', 'amber'], choices: ['moss', 'amber', 'rose'], correct: 'moss', hint: 'Moss, amber, moss, amber… what comes around again?' },
    { sequence: ['rose', 'rose', 'moss', 'rose', 'rose', 'moss'], choices: ['rose', 'moss', 'amber'], correct: 'rose', hint: 'Two roses, one moss. Then the little rhythm begins again.' },
    { sequence: ['amber', 'moss', 'rose', 'amber', 'moss'], choices: ['rose', 'amber', 'moss'], correct: 'rose', hint: 'Amber, moss, rose. Follow the three-step trail.' },
  ];
  const pattern = patterns[round % patterns.length];
  return <div className="pattern-activity">
    <p className="pattern-prompt">{answer === pattern.correct ? 'You found the rhythm.' : answer ? 'Close. Take another look at the rhythm.' : pattern.hint}</p>
    <div className="pattern-row" aria-label="Pattern sequence">{pattern.sequence.map((color, index) => <span key={index} className={`pattern-dot ${color}`} aria-label={color} />)}<span className="pattern-question">?</span></div>
    <div className="pattern-choices">{pattern.choices.map((choice) => <button key={choice} onClick={() => setAnswer(choice)} className={`pattern-choice ${choice} ${answer === choice ? 'chosen' : ''}`} aria-label={`Choose ${choice}`} aria-pressed={answer === choice}><span className={`pattern-dot ${choice}`} />{choice}</button>)}</div>
    <button className="text-button" onClick={() => { setAnswer(null); setRound((value) => value + 1); }}><RotateCcw size={15} /> {answer === pattern.correct ? 'Try another pattern' : 'Reset pattern'}</button>
  </div>;
}

function StoryActivity() {
  const [step, setStep] = useState('start');
  const story = {
    start: { title: 'A note has slipped from a book.', body: 'It is folded into a tiny boat, and one corner is dotted with blue ink. Where might it be going?', options: [{ text: 'Follow the ink-blue thread', next: 'thread' }, { text: 'Ask the sleepy clock', next: 'clock' }] },
    thread: { title: 'The thread leads to a window.', body: 'Beyond it, a paper kite is waiting on the sill. The note fits neatly beneath its tail.', options: [{ text: 'Let the kite carry it', next: 'ending' }, { text: 'Open the note here', next: 'ending' }] },
    clock: { title: 'The clock remembers a breeze.', body: 'It points to the curtains, where a little paper boat is rocking in a fold of cloth.', options: [{ text: 'Set the boat sailing', next: 'ending' }, { text: 'Read the note aloud', next: 'ending' }] },
    ending: { title: 'The note says: “You are right where you need to be.”', body: 'Outside, the light shifts a little. Somewhere, a new page turns.', options: [] },
  } as const;
  const current = story[step as keyof typeof story];
  return <div className="story-activity">
    <div className="story-ornament"><span>✧</span><i /><span>✧</span></div>
    <div className="story-content"><span className="detail-kicker">A SMALL TALE · {step === 'start' ? 'BEGINNING' : step === 'ending' ? 'THE END' : 'A TURN'}</span><h3>{current.title}</h3><p>{current.body}</p>
    {current.options.length ? <div className="story-options">{current.options.map((option) => <button key={option.text} onClick={() => setStep(option.next)}>{option.text}<ArrowRight size={16} /></button>)}</div> : <button className="text-button" onClick={() => setStep('start')}><RotateCcw size={15} /> Read once more</button>}</div>
  </div>;
}

const activityInfo = [
  { id: 'memory', number: '01', title: 'A little remembering', subtitle: 'Find four pairs, at your own pace.' },
  { id: 'pattern', number: '02', title: 'Follow the pattern', subtitle: 'Notice what comes next.' },
  { id: 'story', number: '03', title: 'A note from the window', subtitle: 'Choose a path through a tiny tale.' },
] as const;

function Room() {
  const [, setLocation] = useLocation();
  const [activeNumber, setActiveNumber] = useState('01');
  const [full, setFull] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const activePage = embeddedPages.find((page) => page.number === activeNumber) ?? embeddedPages[0];
  useEffect(() => {
    document.title = 'The Room — Storybook Vault';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) meta.setAttribute('content', 'A tucked-away room with forty pages collected in one place.');
    if (sessionStorage.getItem('storybook-vault-unlocked') !== 'yes') setLocation('/');
  }, [setLocation]);
  async function toggleFullscreen() {
    if (!document.fullscreenElement && iframeRef.current) {
      try { await iframeRef.current.requestFullscreen(); setFull(true); } catch { setFull(false); }
    } else if (document.fullscreenElement) {
      await document.exitFullscreen(); setFull(false);
    }
  }
  useEffect(() => {
    const onFullscreen = () => setFull(Boolean(document.fullscreenElement));
    document.addEventListener('fullscreenchange', onFullscreen);
    return () => document.removeEventListener('fullscreenchange', onFullscreen);
  }, []);
  if (typeof window !== 'undefined' && sessionStorage.getItem('storybook-vault-unlocked') !== 'yes') return null;
  return <main className="room-page">
    <Header room />
    <section className="room-intro">
      <div className="eyebrow"><span className="eyebrow-dot" /> YOU FOUND THE DOOR</div>
      <h1>Welcome to<br />the <i>quiet side.</i></h1>
      <p>All forty pages are gathered below.<br />Choose one to open it here.</p>
      <div className="room-spark">✳</div>
    </section>
    <section className="embed-layout" aria-label="Page collection">
      <nav className="embed-list" aria-label="Choose a page">
        {embeddedPages.map((page) => <button
          key={page.number}
          type="button"
          data-testid={`button-open-page-${page.number}`}
          className={`embed-list-item ${activeNumber === page.number ? 'active' : ''}`}
          onClick={() => setActiveNumber(page.number)}
          aria-current={activeNumber === page.number ? 'page' : undefined}
          aria-label={`Open ${page.title}`}
        >
          <span className="embed-number">{page.number}</span>
          <span data-testid={`text-page-title-${page.number}`}>{page.title}</span>
          <ChevronRight size={15} />
        </button>)}
      </nav>
      <section className="embed-viewer" aria-label={activePage.title}>
        <div className="embed-toolbar">
          <span data-testid="text-active-page-title"><span className="live-dot" /> {activePage.title}</span>
          <button className="fullscreen-button" onClick={toggleFullscreen} aria-label={full ? 'Exit fullscreen' : 'View fullscreen'}>
            <Expand size={16} /> {full ? 'Exit view' : 'Full view'}
          </button>
        </div>
        <div className="embed-frame-shell">
          <iframe
            key={activePage.number}
            src={activePage.url}
            title={activePage.title}
            loading="lazy"
            referrerPolicy="strict-origin-when-cross-origin"
            sandbox="allow-forms allow-scripts allow-same-origin allow-pointer-lock allow-popups allow-presentation"
            allow="autoplay; fullscreen; accelerometer; gyroscope; pointer-lock"
            allowFullScreen
            ref={iframeRef}
          />
        </div>
        <div className="embed-footer">
          <span>Page {activePage.number} of 40</span>
          <a href={activePage.url} target="_blank" rel="noreferrer">Open in a new tab <ArrowRight size={14} /></a>
        </div>
      </section>
    </section>
    <footer className="room-footer"><Link href="/" className="button button-dark"><ArrowLeft size={16} /> Back to the library</Link><span>There will always be another page.</span></footer>
  </main>;
}

function NotFound() {
  const [, setLocation] = useLocation();
  return <main className="not-found"><span className="eyebrow"><span className="eyebrow-dot" /> A PAGE OUT OF PLACE</span><h1>This page wandered<br />off the shelf.</h1><p>Let’s find our way back to the library.</p><button className="button button-dark" onClick={() => setLocation('/')}>Return to the library <ArrowLeft size={16} /></button></main>;
}

function App() {
  return <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Switch><Route path="/" component={Home} /><Route path="/room" component={Room} /><Route component={NotFound} /></Switch></WouterRouter>;
}

export default App;
